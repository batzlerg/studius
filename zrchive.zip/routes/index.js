
/*
 * GET home page
 */

exports.index = function(req, res){
  res.render('index', { title: 'Home' });
};

/*
 * GET registration page
 */

exports.register = function(req, res){
  res.render('register', { title: 'Register' });
};