// USER
/*
 * GET user's courses
 */
exports.main = function(req, res) {
	res.render('user', {
		id: 1
	});
};

exports.allCourses = function(req, res) {
	// get all from user->courses
	db.user.find(function(err,courses) {
		if(err) return;
		res.json(courses);
	});
};

exports.oneCourse = function(req, res) {
	// get one based on ID from user->courses->ID
	db.user.courses.findOne({ "_id" : db.ObjectId(req.params.id) }, function(err, course) {
	    if(err) return;
	    res.json(course);
  	});
};

exports.coursesWithGroup = function(req, res) {
	// get list of courses for which the user is currently in study group
	db.user.find(function(err,courses) {
		if(err) return;
	});
};