require.config({
  'paths': { 
    "underscore": "lib/underscore", 
    "backbone": "lib/backbone"
  }
}); 

require([
  'order!lib/underscore',
  'order!lib/backbone',
  'order!app'
  ], 
  function(_,Backbone,app){
    app.init();
});