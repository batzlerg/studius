define(['jquery', 'backbone', 'underscore'], 
	function($, Backbone, _) {

	  var CourseModel = Backbone.Model.extend({
	  		initialize: function() {
				// do some shit
			},

			defaults: {
				name: null,
				code: [],
				section: null,
				professor: null,
				meetTime: null
			}
	  });
	  
	  return CourseModel;
});