define(['jquery', 'backbone', 'underscore'], 
	function($, Backbone, _) {

	  var UserModel = Backbone.Model.extend({
	  		initialize: function() {
				// do some shit
			},

			defaults: {
				userId: null,
				name: null,
				studentId: null,
				courses: [],
				groups: [],
				canvasToken, null
			}
	  });
	  
	  return UserModel;
});