define(['jquery', 'backbone', 'underscore'], 
	function($, Backbone, _) {

	  var GroupModel = Backbone.Model.extend({
	  		initialize: function() {
				// do some shit
			},

			defaults: {
				students: [],
				date: null,
				time: null,
				location: null,
				details: null,
				creator: null,
			}
	  });
	  
	  return GroupModel;
});