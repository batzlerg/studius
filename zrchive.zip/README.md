## Node, Express, RequireJS and Backbone Starter
This application is a starting point to design a modular application using Node, Express, RequireJS, and Backbone.  

There are simple examples of how to write a router, view, and model.  

Feel free to fork and use in your own BackboneJS app!

Thanks to jcreamer898 for the RequireJS and Backbone starter.